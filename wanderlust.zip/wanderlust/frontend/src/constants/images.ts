export const imageUrls: string[] = [
  'https://i.ibb.co/3z72vmc/clean-lake-mountains-range-trees-nature-4k.webp',
  'https://i.ibb.co/y8vQnDc/c4fedab1-4041-4db5-9245-97439472cf2c.webp',
  'https://i.ibb.co/BNjv5Nn/London-Skyline-125508655.webp',
  'https://i.ibb.co/d0g42nr/FPO-BOR-100-800x600.webp',
  'https://i.ibb.co/52mk2Yq/sunset-pier.webp',
  'https://i.ibb.co/KLwfZzG/Maldives-1024x767.webp',
  'https://i.ibb.co/qxFMj1H/sunset-horizon-clean-sky-nature.webp',
];
